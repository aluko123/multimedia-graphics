---Fola Aluko---
---setting.lua--

local composer = require( "composer" )
local scene = composer.newScene()
local widget = require("widget")


local function switchOverlay()
	local options = {
		isModal = true,
		effect = "fade",
		time = 500
	}
	composer.showOverlay( "Alabamamap" , options )
end

function scene:create(event)

	local sceneGroup = self.view

	 composer.setVariable( "option", 0 )
	 

	local switchButton = widget.newButton({
		left = 150,
		top = 50,
		shape = "roundedRect",
		width = 150,
		height = 30,
		labelColor = { default = {0, 0, 0}},
		label = "Switch Scenes",
		onPress = switchOverlay
		})

	sceneGroup:insert(switchButton)

	local function caseRadioButton(event) --function for case radio on
		state = "Case"	
		option = 0
		print("System mode set to "..state)
	end

	local function deathRadioButton(event) --function for death radio on
		state = "Death"
		option = 1
		print("System mode set to "..state)
	end



	local radGroup = display.newGroup()  --group for radio buttons
	local radRect = display.newRoundedRect( radGroup, 80, 240, 100, 110, 5 )
	local caseT = display.newText( "Case", 105, 215, 'New Times Roman', 15) -- case radio button text
	local deathT = display.newText( radGroup, "Death", 105, 270, 'New Times Roman', 15 ) -- death radio buttons
	radRect.strokeWidth = 4
	radRect.alpha = 0.2 -- make the rounded rect a bit transparent



	local case = widget.newSwitch({
		left = 50,
		top = 200,
		style = "radio",
		id = "caseRadio",
		initialSwitchState = true,
		onPress = caseRadioButton
		}) -- This creates a the low button for the radio

	radGroup:insert(case)


	local death = widget.newSwitch({
		left = 50,
		top = 250,
		style = "radio",
		id = "deathRadio",
		onPress = deathRadioButton
		}) -- This created a high button for the radio

	radGroup:insert(death)
	sceneGroup:insert(radGroup)



end

--show the scene ---
function scene:show(event)

	local sceneGroup = self.view
	local phase = event.phase

	if( phase == "will" ) then


	else if( phase == "did" ) then



	end
end
end


function scene:hide( event )
	local sceneGroup = self.view
end


function scene:destroy( event )
	local sceneGroup = self.view




end

scene:addEventListener("create", scene)
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )
 

return scene