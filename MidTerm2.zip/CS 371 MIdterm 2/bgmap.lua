
-- just copy and paste this in your code to display the Alabama map.
local bg = display.newImage ("al_map.png", display.contentCenterX, display.contentCenterY);
bg.xScale = display.contentWidth / bg.width; 
bg.yScale = display.contentHeight / bg.height;