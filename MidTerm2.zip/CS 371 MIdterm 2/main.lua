--main.lua
-- Fola Aluko

local composer = require("composer")
display.setStatusBar(display.HiddenStatusBar)

composer.gotoScene("setting")