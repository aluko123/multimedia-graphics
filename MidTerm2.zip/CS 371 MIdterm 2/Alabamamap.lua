--Fola Aluko---
--Alabamamap---


local composer = require ("composer")
local scene = composer.newScene()
local csv = require ("csv")
local widget = require ("widget")
local map = require ("map")
local path = system.pathForFile ("new_covid_al.csv")
local file = csv.open(path, {seperator = ",", header = true})

local balls = {}
local displayvalue
local deltaX = math.random()*10
local deltaY = math.random()*10

-- just copy and paste this in your code to display the Alabama map.
	local bg = display.newImage ("al_map.png", display.contentCenterX, display.contentCenterY);
	bg.xScale = display.contentWidth / bg.width; 
	bg.yScale = display.contentHeight / bg.height;
	

local function showScene1()
	local options = {
		effect = "fade",
		time = 500
	}
	composer.hideOverlay()
end

local function handleButtonEvent(event)
	if( "ended" == event.phase) then
		showScene1()
	end
end

function scene:create(event)

	

	local sceneGroup = self.view

	local caseOrDeath = composer.getVariable( "option")
	

	local function tapListener( event )
 
    	if ( event.numTaps > 1 ) then
        	showScene1()
        end
    end
    sceneGroup:addEventListener( "tap", tapListener )


	function map (value, istart, istop, ostart, ostop) 
    	return ostart + (ostop - ostart) * ((value - istart) / (istop - istart));
  	end



	for record in file:lines() do
		local zip = record.Zip
		local x = record.x
		local y = record.y
		local city = record.City
		local case = record.Case
		local death = record.Death
		local ballGroup = display.newGroup()

	
		local radius1 =  map(case,882, 114709, 5, 20)
		local radius2 = map(death,27, 1924, 5, 20)
		local zipText = display.newText("zip", 280, 130, native.systemFont)

		local xCoord = x
		local yCoord = y

			if( caseOrDeath == 0) then
				local ball1 = display.newCircle( ballGroup, xCoord, yCoord, radius1)	
				ball1:setFillColor(1, 1, 0, 0.6)

			else if( caseOrDeath == 1) then
				local ball2 = display.newCircle( ballGroup, xCoord, yCoord, radius2)
				ball2:setFillColor(1, 1, 0, 0.6)
			end

		ballGroup.deltaX = 10
		ballGroup.deltaY = 10
		local ballText = display.newText(ballGroup, city, xCoord, yCoord, native.systemFont, radius2)

		ballGroup.x = xCoord
		ballGroup.y = yCoord

		local function zipCode(zip)
   			local value = map(zip,0, 100, 35004, 36925)
  			displayvalue = map(zip,0, 100, 35004, 36925)
		    zipText.text = displayvalue

		    for _, ball in ipairs(balls) do
			if ball.zip <  displayvalue then
				ball.isVisible = true
			else
				ball.isVisible = false
			end
		end
		    --composer.setVariable( "totalSpeed", value )
		end
		table.insert(balls, ballGroup)
		sceneGroup:insert(ballGroup)	
	end

		

		local speedSlider = widget.newSlider({
    		top = 110,
   	 		left = 20,
    		orientation = "horizontal",
   			width = 200,
    		value = 50,
    		listener = zipCode
    }) --Size slider generation

	zipText:toFront( )
	zipText:setFillColor( 0,0,0 )	
	sceneGroup:insert(speedSlider)
	sceneGroup:insert(zipText)


	timer.performWithDelay( 10, zipCode, 0 )

end
end


--show the scene ---
function scene:show(event)

	local sceneGroup = self.view
	local phase = event.phase

	if( phase == "will" ) then

	
	else if( phase == "did" ) then

	end
end



function scene:hide( event )
	local sceneGroup = self.view
end


function scene:destroy( event )
	local sceneGroup = self.view

end

scene:addEventListener("create", scene)
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )
 
end

return scene

