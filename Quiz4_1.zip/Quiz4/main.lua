local composer = require("composer")

display.setStatusBar(display.HiddenStatusBar)

composer.gotoScene("scene1", options)

--[[
local barney_opt = {
    frames = {
        {x = 3, y = 1, width = 74, height = 80}, -- frame 1
        {x = 94, y = 3, width = 66, height = 82}, -- frame 2
        {x = 176, y = 5, width = 61, height = 83}, -- frame 3
        {x = 250, y = 4, width = 61, height = 83}, -- frame 4
        {x = 318, y = 6, width = 61, height = 80}, -- frame 5
        {x = 381, y = 6, width = 64, height = 80} -- frame 6
    }
}

local barney_sheet = graphics.newImageSheet("barney.png", barney_opt)

local barney_sequenceData = {
    {name = "walking", frames = {1, 2, 3, 4, 5, 6}, time = 700, loopCount = 0}
}



local sheet = barney_sheet;
local sequenceData = barney_sequenceData;


local anim = display.newSprite(sheet, sequenceData)
anim:setSequence("walking")
anim.x = display.contentCenterX
anim.y = display.contentCenterY

local function moveToTap(event)
    transition.to(anim, {
        time = 2000,
        x = event.x,
        y = event.y,
        onStart = function() anim:play() end,
        onComplete = function() anim:pause() end
    })
    return
end

Runtime:addEventListener("tap", moveToTap)
]]--