local widget = require( "widget" )
     
-- Slider listener
local function sliderListener( event )
    print( "Slider at " .. event.value .. "%" )
end
 
-- Create the widget
local slider = widget.newSlider(
    {
        x = display.contentCenterX,
        y = display.contentCenterY,
        width = 400,
        value = 10,  -- Start slider at 10% (optional)
        listener = sliderListener
    }
)