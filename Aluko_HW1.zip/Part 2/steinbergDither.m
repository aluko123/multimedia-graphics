
function output = steinbergDither(imageFile)

    %read image file
    sourceImg = imread(imageFile);
    %imshow(sourceImg);


    %convert to grayscale and normalize
    grayImg = double(im2gray(sourceImg))./255;

    %make new image matrix of the proper size
    [rows, cols] = size(grayImg);
    %ditheredImg = grayImg;
    %fprintf(grayImg);

    %loop through each pixel and replace with new dithered pixel, from left
    %to right
    for j = 1:cols 
        for i = 1:rows
            %get value of pixel
            oldPixel = grayImg(i, j);
            newPixel = truncate(oldPixel);
            grayImg(i, j) = newPixel;
            quantError = oldPixel - newPixel;

            %handle error diffusion
            if(i + 1 <= rows)
                grayImg(i+1,j) = grayImg(i+1,j) + quantError * 7.0/16.0;
            end
            if(i - 1 >= 1) && ( j + 1 <= cols)
                grayImg(i-1,j+1) = grayImg(i-1,j+1) + quantError * 3.0/16.0;
            end
            if(j + 1 <= cols)
                grayImg(i,j+1) = grayImg(i,j+1) + quantError * 5.0/16.0;
            end
            if(i + 1 <= rows) && ( j + 1 <= cols)
                grayImg(i+1,j+1) = grayImg(i+1,j+1) + quantError * 1.0/16.0;
            end
        end
    end

    %convert double matrix into 3d uint8 rgb matrix
    intImg = uint8(grayImg.*255);
    rgbImg = zeros(rows, cols, 3);
    for i = 1:3
        rgbImg(:, :, i) = intImg(:, :);
    end
    output = rgbImg;

    %show new dithered image
    h = imshow(output);
    imsave(h);
    end



function  newVal = truncate(oldpixel)
    if (oldpixel < 0.5)
        newVal = 0;  %black
    else
        newVal = 1;  %white
    end
end












