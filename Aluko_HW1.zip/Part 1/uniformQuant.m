function output = uniformQuant(imageFileName, rgbBitDepth)

    sourceImg = imageFileName;

    %changing to gray matrix
    %grayImg = rgb2gray(sourceImg);

    

    %newImg = grayImg;

    %quantize
    outputR = uint8(sourceImg(:,:,1)./(256/2^rgbBitDepth(1,1)));
    outputG = uint8(sourceImg(:,:,2)./(256/2^rgbBitDepth(1,2)));
    outputB = uint8(sourceImg(:,:,3)./(256/2^rgbBitDepth(1,3)));

    outputR = uint8(outputR.*(256/2^rgbBitDepth(1,1)));
    outputG = uint8(outputG.*(256/2^rgbBitDepth(1,2)));
    outputB = uint8(outputB.*(256/2^rgbBitDepth(1,3)));
    
    %disp(size(sourceImg))
    %test
    %outputR = uint8(sourceImg(:,:,1)./(256/2^3));
    %outputG = uint8(sourceImg(:,:,2)./(256/2^3));
    %outputB = uint8(sourceImg(:,:,3)./(256/2^2));



    %outputR = uint8(outputR.*(256/2^3));
    %outputG = uint8(outputG.*(256/2^3));
    %outputB = uint8(outputB.*(256/2^2));

    output = cat(3, outputR, outputG, outputB);
    %disp(size(output));
    %imshow(output);
    
    end